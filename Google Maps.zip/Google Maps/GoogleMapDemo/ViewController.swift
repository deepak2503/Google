//
//  ViewController.swift
//  GoogleMapDemo
//
//  Created by tag on 12/18/15.
//  Copyright © 2015 tag. All rights reserved.
//

import UIKit

class ViewController: UIViewController
{
    
    //    MARK: - View Life Cycle Methods
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }
}